<?php
	include('../config.php');
	error_reporting(0);
	include('header.php');
?>
	<!-- BEGIN PAGE CONTENT -->
        <div class="page-content">
  			<div class="header">
            <h2><strong>CATEGORY</strong></h2>
            <div class="breadcrumb-wrapper">
              <ol class="breadcrumb">
                <li><a href="dashboard.html">Dashboard</a>
                </li>
                <li class="active">Category</li>
              </ol>
            </div>
          </div>
		<div class="row">
			<div class="col-lg-12 portlets">
			  <div class="panel">
				<div class="panel-header panel-controls">
				  <h3><i class="fa fa-table"></i> <strong>Sorting </strong> table</h3>
				</div>
				<div class="panel-content pagination2 table-responsive">
				  <table class="table table-hover table-dynamic">
					<thead>
					  <tr>
						<th> No. </th>
						<th> City </th>
						<th> Country </th>
						<th> Edit </th>
						<th> Remove </th>
					  </tr>
					</thead>
					<tbody>
					<?php 
					$num = 0;
					$sql1 = mysqli_query ($con,"SELECT * FROM `city`");
					while($row1 = mysqli_fetch_array($sql1))
					{
						$num = $num + 1;
						$cid = $row1['country_id'];
						$sql2 = mysqli_query ($con,"SELECT * FROM `country` WHERE id = '$cid'");
						$row2 = mysqli_fetch_array($sql2);
					?>
					  <tr>
						<td><?php echo $num; ?></td>
						<td><?php echo $row1['citynm']; ?></td>
						<td><?php echo $row2['countrynm']; ?></td>
						<td><a href="location.php?sid=<?php echo $row1['id']; ?>&edit=edit" class="btn btn-primary">Edit</a></td>
						<td><a href="location.php?sid=<?php echo $row1['id']; ?>&remove=remove" class="btn btn-primary">Remove</a></td>
					  </tr>
					 <?php 
					 }
					?>
					</tbody>
				  </table>
				</div>
			  </div>
			</div>
		  </div>	
	</div> 
        
<?php
	include('footer.php');
?>