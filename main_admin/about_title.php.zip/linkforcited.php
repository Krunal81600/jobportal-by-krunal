https://en.wikipedia.org/wiki/List_of_cities_and_towns_in_Kenya_by_population : 50 from all list
https://www.ask-aladdin.com/Egypt_cities/
https://simple.wikipedia.org/wiki/List_of_cities_in_Libya 26from list